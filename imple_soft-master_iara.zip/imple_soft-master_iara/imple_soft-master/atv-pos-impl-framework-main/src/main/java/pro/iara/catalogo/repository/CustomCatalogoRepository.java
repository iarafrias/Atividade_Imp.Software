package pro.iara.catalogo.repository;

import pro.iara.catalogo.model.Musica;

import java.util.List;

public interface CustomCatalogoRepository {
    List<Musica> findAllByTituloUpper(String titulo);
}
